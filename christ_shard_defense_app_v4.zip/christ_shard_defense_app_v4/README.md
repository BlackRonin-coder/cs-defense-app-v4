# Christ Shard Defense Workbench v4

Protected core AI defense demonstrator using the Christ Shard Sovereign Kernel.

## Current Status
- Kernel is working (healthy governance state)
- Threat evaluation and protection active
- Write Lock governance engaged

## How to Run
```bash
cd christ_shard_defense_app_v4
python3 run_demo.py
cd ..
zip -r christ_shard_defense_app_v4.zip christ_shard_defense_app_v4

cd ..
zip -r christ_shard_defense_app_v4.zip christ_shard_defense_app_v4
ls -lh *.zip
cd ..
zip -r christ_shard_defense_app_v4.zip christ_shard_defense_app_v4

ls -lh *.zip
